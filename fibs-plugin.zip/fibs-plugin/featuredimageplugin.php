<?php
  /*
  Plugin Name: Featured Image Bulk Set
  Plugin URI: https://github.com/foghorn/fibs
  description: A plugin to set the featured image for posts where none exists using the first image in the post
  Version: 1.3
  Author: Nick Leghorn
  Author URI: https://blog.nickleghorn.com
  License: GPL2
  */

  //Validate image and insert
  function fibs_CheckAndPost($ID,$image,$real)
  {
    $ID = sanitize_text_field($ID);
    $image = sanitize_text_field($image);
    $real = sanitize_text_field($real);

    //Check that the two posts passed are a number
    if ((is_numeric($image)) AND  (is_numeric($ID)))
    {
      //Make sure we are setting for a post
      if (get_post_status($ID) != FALSE)
      {
        //Check that this number is actually a Post ID of an image attachment
        if (wp_attachment_is_image($image))
        {
          //Check that the end user really wants to do this
          if ($real == 1)
          {
            set_post_thumbnail($ID,$image);
          }
          //Otherwise, tell them what would have happened
          else
          {
            echo "Would have set image " . wp_kses($image,array()) . "<br>";
          }
        }
        else
        {
          echo "ERROR: Identified image ID is not an image<br>";
        }
      }
      else
      {
        echo "ERROR: Tried to set the featured image for something that is not a post<br>";
      }
    }
    else
    {
      echo "ERROR: Either the Post ID or the Featured Image ID are not a number<br>";
    }
  }


  function fibs_add_settings_page() {
  add_options_page( 'Featured Image Bulk Set', 'FIBS Menu', 'manage_options', 'fibs_plugin', 'fibs_render_plugin_settings_page' );
  }
  add_action( 'admin_menu', 'fibs_add_settings_page' );

  function fibs_render_plugin_settings_page() {
    //Sanitize user input
    $execute = sanitize_text_field($_GET['execute']);
    $secretcheck = sanitize_text_field($_POST['secretcheck']);
    $dim = sanitize_text_field($_POST['dim']);
    $override = sanitize_text_field($_POST['override']);
    $forreal = sanitize_text_field($_POST['forreal']);
    $firstlast = sanitize_text_field($_POST['firstlast']);
    
    //Get and sanitize table name
    global $wpdb;
    $prefix = $wpdb->prefix;
    $tablename = sanitize_text_field($prefix  . "posts");
    ?>
    <h2>Featured Image Bulk Set Functionality</h2>
    <?php

    if ($execute != 1)
    {
      ?>
        <form action="options-general.php?page=fibs_plugin&execute=1" method="post">

        <!-- INVISIBLE CHECK -->
        <input type="hidden" id="secretcheck" name="secretcheck" value="1">

        <!-- FIRST OR LAST -->
        <h3>First or Last Image for Default?</h3>
        <input type="radio" id="first" name="firstlast" value="1" checked="checked"> First Image<br>
        <input type="radio" id="first" name="firstlast" value="0"> Last Image<br>
        <br>

        <!-- DEFAULT IMAGE -->
        <h3>Set a Default Image for Posts Without Images?</h3>
        <input type="text" id="dim" name="dim"><br>
        (Use image ID. Leave blank to set NO image in those cases.)<br>
        <br>
        <input type="checkbox" id="override" name="override" value="1">
        <label for="override"> Override finding images in posts?</label><br>
        NOTE: Setting this option will set this image as the Featured Image for ALL posts without a current Featured Image, even those that contain images.<br>
        <br>

        <!-- TEST OR REAL -->
        <h3>Do it for real?</h3>
        <input type="checkbox" id="forreal" name="forreal" value="1">
        <label for="forreal"> Yes!</label><br>
        <br>


        <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Save' ); ?>" />
        </form>
      <?php
    }
    elseif ($secretcheck == 1)
    {

      //Make sure the default featured image, if set, is actually a usable image
      if ((($dim != NULL) OR ($dim != 0)) AND ((is_numeric($dim) == FALSE) OR (wp_attachment_is_image($dim) == FALSE)))
      {
        echo "ERROR: Entered default featured image is not correct, please check and ensure that you entered the correct Post ID for the required featured image.<br>";
      }
      else
      {
        $con=mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

        $A = mysqli_query($con,"SELECT * FROM " . $tablename . " WHERE post_type = 'post'");
        while($B = mysqli_fetch_array($A))
        {
          //Sanitize database returns
          $Return_ID = sanitize_text_field($B['ID']);
          
          echo "<br>Checking " . wp_kses($Return_ID,array()) . "<br>";

          
          //Check that there is a featured image
          if (get_post_thumbnail_id($Return_ID) == FALSE)
          {
            echo "NO FEATURED IMAGE!<br>";
            
            //Find featured image
            $img_ref = '';
            $img_slice = '';
            
            //Grab the post content
            $E = mysqli_query($con,"SELECT post_content FROM " . $tablename . " WHERE ID = '" . $Return_ID . "'");
            $F = mysqli_fetch_array($E);

            //Sanitize content
            $return_content = wp_kses_post($F['post_content']);

            if (strlen($return_content) > 0)
            {
              echo "Grabbed post: " . wp_kses(md5($return_content),array()) . "<br>";
              
              //Check override
              if ( (strlen($dim) > 0) AND ($override == 1) )
              {
                //Check that this is really an image and post
                fibs_CheckAndPost($Return_ID,$dim,$forreal);
              }
              //is there an image to be found?
              elseif (substr_count($return_content,'wp-image-'))
              {
                echo "Image found!<br>";
                
                //First or last image?
                if ($firstlast == 1)
                {
                  //Identify the first wp-image- referenced
                  $img_ref = stripos($return_content,'wp-image-');

                  $img_slice = substr($return_content,$img_ref);

                  //Find where this string ends
                  $counter = 9;

                  while (preg_match('/^[a-zA-Z0-9\-]$/',substr($img_slice,$counter,1)))
                  {
                    $counter++;
                  }

                  //Slice string to just post ID
                  $thumbnailID = substr($img_slice,9,($counter - 9));

                  fibs_CheckAndPost($Return_ID,$thumbnailID,$forreal);
                  
                }
                else
                {
                  //Identify the last wp-image- referenced
                  $img_ref = strripos($return_content,'wp-image-');

                  $img_slice = substr($return_content,$img_ref);

                  //Find where this string ends
                  $counter = 9;

                  while (preg_match('/^[a-zA-Z0-9\-]$/',substr($img_slice,$counter,1)))
                  {
                    $counter++;
                  }

                  //Slice string to just post ID
                  $thumbnailID = substr($img_slice,9,($counter - 9));

                  fibs_CheckAndPost($Return_ID,$thumbnailID,$forreal);
                }

              }
              elseif (strlen($dim) > 0)
              {
                //Check that this is really an image and post
                fibs_CheckAndPost($Return_ID,$dim,$forreal);
                              
              }
              else
              {
                  echo "ERROR: No image found<br>";
              }

            }
            else
            {
                echo "ERROR: Zero length post<br>";
            }
            
          }
          else
          {
            echo "FEATURED IMAGE SET!<br>";
          }
        }
        echo '<br><br>FINSIHED: <a href="options-general.php?page=fibs_plugin">Back to the beginning!</a>';
      }
          
    }
    else
    {
      echo 'ERROR: <a href="options-general.php?page=fibs_plugin">Please click here to try again</a>';
    }

  }
?>